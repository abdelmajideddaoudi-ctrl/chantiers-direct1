# Chantiers Direct

Plateforme qui met à disposition des professionnels (artisans, entreprises, prestataires) les chantiers issus de votre prospection commerciale. Les pros paient pour accéder aux coordonnées du client.

## Modèle de revenus (réglable dans Administration > Réglages)

| Formule | Ce que paie le pro | Ce qu'il obtient |
| --- | --- | --- |
| Découverte | 0 € | Liste des chantiers (résumé, ville, budget) |
| À l'unité | % du budget estimé (avec minimum et maximum) ou prix fixe par chantier | Coordonnées complètes du client |
| Abonnement Pro | Montant mensuel récurrent | Descriptions complètes + remise sur chaque accès |

Chaque chantier est limité à un nombre de places (pros) pour garder de la valeur.

## Fonctionnement technique

- `public/` : site (HTML, CSS, JavaScript, sans compilation)
- `netlify/functions/api.mjs` : API `/api/*`
- `src/server/` : logique (stockage Netlify Blobs, sessions, tarifs, Stripe)
- Données stockées dans Netlify Blobs (store `chantiers-direct`)

## Variables d'environnement (Netlify > Project configuration > Environment variables)

| Variable | Rôle |
| --- | --- |
| `ADMIN_EMAIL` | E-mail de connexion de l'administrateur |
| `ADMIN_PASSWORD` | Mot de passe administrateur (secret) |
| `SESSION_SECRET` | Clé de signature des sessions (secret, longue et aléatoire) |
| `STRIPE_SECRET_KEY` | Clé secrète Stripe `sk_live_…` (ou `sk_test_…` pour tester) |
| `STRIPE_WEBHOOK_SECRET` | Secret du webhook Stripe `whsec_…` |

Après toute modification d'une variable : Deploys > Trigger deploy.

## Activer le paiement par carte (Stripe)

1. Créer un compte sur stripe.com (SIRET, IBAN, pièce d'identité).
2. Developers > API keys : copier la clé secrète dans `STRIPE_SECRET_KEY`.
3. Developers > Webhooks > Add endpoint : URL `https://VOTRE-SITE/api/stripe/webhook`, événements `checkout.session.completed`, `invoice.paid`, `customer.subscription.deleted`. Copier le « Signing secret » dans `STRIPE_WEBHOOK_SECRET`.
4. Redéployer. Dans Administration > Réglages, décocher « Mode test ».

Paiements hors ligne (virement, espèces…) : Administration > Professionnels > « Enregistrer un paiement ».
